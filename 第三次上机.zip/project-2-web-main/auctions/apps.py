"""Auctions apps module."""
from django.apps import AppConfig


class AuctionsConfig(AppConfig):
    """Application config class"""

    name = "auctions"
